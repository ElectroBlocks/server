 MAX7219\_Dot\_Matrix
====================

Arduino library for MAX7219 display using SPI.

For use with 8x8 LED dot-matrix displays.


For details about the theory, wiring, schematic, etc. see:

[Read more](http://www.gammon.com.au/forum/?id=11516)


The bit-banged SPI library used in this library can be found at:

[bitBangedSPI](https://github.com/nickgammon/bitBangedSPI)
